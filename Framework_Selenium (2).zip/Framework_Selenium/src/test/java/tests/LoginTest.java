package tests;
import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import framework.BaseTest;
import framework.DriverFactory;

public class LoginTest extends BaseTest{

	public static String name1 ;
	@Test
	public void test1() {
		System.out.println("Test 1 Executed");
		assertEquals(DriverFactory.getInstance().getDriver().getTitle(), "Google");
	}
	
	@Test
	public void test2() {
		System.out.println("Test 2 Executed");
		assertEquals(DriverFactory.getInstance().getDriver().getTitle(), "Google Site");
	}
	
	@Test
	public void test3() {
		System.out.println("Test 3 Executed");
		DriverFactory.getInstance().getDriver().findElement(By.name("q")).sendKeys("Mayur");
		assertEquals(DriverFactory.getInstance().getDriver().getTitle(), "Google Test");
	}
	
}
