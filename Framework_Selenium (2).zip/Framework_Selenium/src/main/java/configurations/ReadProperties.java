package configurations;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class ReadProperties {

	public static String getProperty(String property) throws IOException {
		
		Properties prop =  new Properties();
		FileInputStream fis = new FileInputStream(System.getProperty("user.dir")+"//src//main//resources//config.properties");
		prop.load(fis);
		String value = prop.getProperty(property).trim();
		return value;
	}
	
}
