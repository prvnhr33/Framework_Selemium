package framework;

import com.relevantcodes.extentreports.ExtentTest;

public class ExtentFactoryNG {
	
	private ExtentFactoryNG() {
		
	}
	
	private static ExtentFactoryNG instance = new ExtentFactoryNG();
	
	public static ExtentFactoryNG getInstance() {
		return instance;
	}
	
	ThreadLocal<ExtentTest> extentTest = new ThreadLocal<>(); 
	
	public ExtentTest getExtent() {
		return extentTest.get();
	}
	
	public void setExtent(ExtentTest test) {
		extentTest.set(test);
	}
	
	public void closeExtent() {
		
		extentTest.remove();
	}
	
}
