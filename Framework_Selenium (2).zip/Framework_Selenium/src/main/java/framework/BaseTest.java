package framework;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import configurations.ReadProperties;

public class BaseTest {
	
	public static WebDriver driver;
	
	BrowserFactory bf = new BrowserFactory();
	
	@BeforeMethod
	public void runBrowserInstance() throws IOException {
		DriverFactory.getInstance().setDriver(bf.getBrowserInstance(ReadProperties.getProperty("browser")));
		WebDriver driver = DriverFactory.getInstance().getDriver();

		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.navigate().to(ReadProperties.getProperty("url"));
	}
	
	@AfterMethod
	public void tearDown() {
		//driver.close();
		DriverFactory.getInstance().closeDriver();
	}
	
	
	
	
}
