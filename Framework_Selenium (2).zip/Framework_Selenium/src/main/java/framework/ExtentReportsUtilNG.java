package framework;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.relevantcodes.extentreports.ExtentReports;

public class ExtentReportsUtilNG 
{
	static ExtentReports reports ;
	public static ExtentReports setExtentReport()
	{
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yy HH-mm-ss");
		Date date = new Date();
		String dateToday = sdf.format(date);
		String reportPath = System.getProperty("user.dir")+"//reports//Summary_Report_"+dateToday+".html";
		reports =  new ExtentReports(reportPath);
		reports.assignProject("Automation Reports");
		return reports;	
	}
	
	
	
	
}
