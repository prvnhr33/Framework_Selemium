package framework;

import com.aventstack.extentreports.ExtentTest;

public class ExtentFactory {
	
	private ExtentFactory() {
		
	}
	
	private static ExtentFactory instance = new ExtentFactory();
	
	public static ExtentFactory getInstance() {
		return instance;
	}
	
	ThreadLocal<ExtentTest> extentTest = new ThreadLocal<>(); 
	
	public ExtentTest getExtent() {
		return extentTest.get();
	}
	
	public void setExtent(ExtentTest test) {
		extentTest.set(test);
	}
	
	public void closeExtent() {
		
		extentTest.remove();
	}
	
}
