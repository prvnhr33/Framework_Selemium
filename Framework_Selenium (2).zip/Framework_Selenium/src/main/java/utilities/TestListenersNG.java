package utilities;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import framework.DriverFactory;
import framework.ExtentFactoryNG;
import framework.ExtentReportsUtilNG;

public class TestListenersNG implements ITestListener{

	static ExtentReports report;
	static ExtentTest test ;

	@Override  
	public void onTestStart(ITestResult result) {
		try {
			test = report.startTest(result.getMethod().getMethodName()+" : "+ result.getTestClass().getRealClass().getDeclaredField("name1").get(result.getInstance()));
			ExtentFactoryNG.getInstance().setExtent(test);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}  

	@Override  
	public void onTestSuccess(ITestResult result) {  
		// TODO Auto-generated method stub  
		System.out.println("Success of test cases and its details are : "+result.getName());
		ExtentFactoryNG.getInstance().getExtent().log(LogStatus.PASS, "Passed");
		
	}  

	@Override  
	public void onTestFailure(ITestResult result) {  
		// TODO Auto-generated method stub  
		System.out.println("Failure of test cases and its details are : "+result.getName());  
		File f = ((TakesScreenshot)DriverFactory.getInstance().getDriver()).getScreenshotAs(OutputType.FILE);
		String screenPath = System.getProperty("user.dir")+"_"+result.getMethod().getMethodName()+"_"+"Test.png";
		try {
			FileUtils.copyFile(f, new File(screenPath));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ExtentFactoryNG.getInstance().getExtent().log(LogStatus.FAIL, "Screenshot for failure"+ExtentFactoryNG.getInstance().getExtent().addScreenCapture(screenPath));
		ExtentFactoryNG.getInstance().getExtent().log(LogStatus.FATAL, "Failure Reason"+result.getThrowable());
		//addScreenCaptureFromPath(screenPath, result.getMethod().getMethodName()+" successfully passed.");
		ExtentFactoryNG.getInstance().closeExtent();
	}  

	@Override  
	public void onTestSkipped(ITestResult result) {  
		// TODO Auto-generated method stub  
		System.out.println("Skip of test cases and its details are : "+result.getName());  
	}  

	@Override  
	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {  
		// TODO Auto-generated method stub  
		System.out.println("Failure of test cases and its details are : "+result.getName());  
	}  

	@Override  
	public void onStart(ITestContext context) {  
		//report = ExtentReportsUtil.setExtentReport();
		report = ExtentReportsUtilNG.setExtentReport();
	}  

	@Override  
	public void onFinish(ITestContext context) {  
		report.flush();
		
	}  

}
