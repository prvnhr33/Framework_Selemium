package utilities;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import framework.DriverFactory;
import framework.ExtentFactory;
import framework.ExtentReportsUtil;

public class TestListeners implements ITestListener{

	static ExtentReports report;
	static ExtentTest test ;

	@Override  
	public void onTestStart(ITestResult result) {
		try {
			test = report.createTest(result.getMethod().getMethodName());
			ExtentFactory.getInstance().setExtent(test);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}  

	@Override  
	public void onTestSuccess(ITestResult result) {  
		// TODO Auto-generated method stub  
		System.out.println("Success of test cases and its details are : "+result.getName());
		
	}  

	@Override  
	public void onTestFailure(ITestResult result) {  
		// TODO Auto-generated method stub  
		System.out.println("Failure of test cases and its details are : "+result.getName());  
		File f = ((TakesScreenshot)DriverFactory.getInstance().getDriver()).getScreenshotAs(OutputType.FILE);
		String screenPath = System.getProperty("user.dir")+"_"+result.getMethod().getMethodName()+"_"+"Test.png";
		try {
			FileUtils.copyFile(f, new File(screenPath));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ExtentFactory.getInstance().getExtent().log(Status.FAIL, result.getThrowable());
		ExtentFactory.getInstance().getExtent().addScreenCaptureFromPath(screenPath, result.getMethod().getMethodName()+" successfully passed.");
		ExtentFactory.getInstance().closeExtent();
		ExtentFactory.getInstance().closeExtent();
	}  

	@Override  
	public void onTestSkipped(ITestResult result) {  
		// TODO Auto-generated method stub  
		System.out.println("Skip of test cases and its details are : "+result.getName());  
	}  

	@Override  
	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {  
		// TODO Auto-generated method stub  
		System.out.println("Failure of test cases and its details are : "+result.getName());  
	}  

	@Override  
	public void onStart(ITestContext context) {  
		//report = ExtentReportsUtil.setExtentReport();
		report = ExtentReportsUtil.setExtentReport();
	}  

	@Override  
	public void onFinish(ITestContext context) {  
		report.flush();
		
	}  

}
