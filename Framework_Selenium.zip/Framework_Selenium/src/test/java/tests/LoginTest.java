package tests;
import org.testng.annotations.Test;

import framework.BaseTest;

public class LoginTest extends BaseTest{

	@Test
	public void test1() {
		
		System.out.println("Test 1 Executed");
		
	}
	
	@Test
	public void test2() {
		
		System.out.println("Test 2 Executed");
		
	}
	
	@Test
	public void test3() {
		
		System.out.println("Test 3 Executed");
		
	}
	
}
