package framework;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BrowserFactory {

	static WebDriver driver;
	
	public WebDriver getBrowserInstance(String browser) throws IOException {
		
		if(browser.equalsIgnoreCase("chrome")) {
			
			ChromeOptions option = new ChromeOptions();
			option.addArguments("--incognito");
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
		}	
		
		return driver;
	}
	
}
